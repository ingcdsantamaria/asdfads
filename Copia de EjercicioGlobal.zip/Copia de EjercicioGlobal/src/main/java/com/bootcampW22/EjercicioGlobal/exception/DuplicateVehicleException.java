package com.bootcampW22.EjercicioGlobal.exception;

public class DuplicateVehicleException extends RuntimeException {
  public DuplicateVehicleException(String message) {
    super(message);
  }
}
